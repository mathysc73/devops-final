import pytest
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from app import app as flask_app


@pytest.fixture
def client():
    flask_app.config['TESTING'] = True
    with flask_app.test_client() as client:
        yield client


# ── Tests de base ────────────────────────────────────────────────────────
def test_index_returns_200(client):
    """La page d'accueil doit répondre 200."""
    response = client.get('/')
    assert response.status_code == 200


def test_health_check(client):
    """Le healthcheck doit retourner status ok."""
    response = client.get('/health')
    assert response.status_code == 200
    data = response.get_json()
    assert data['status'] == 'ok'
    assert data['service'] == 'fps-tracker'
    assert data['players_tracked'] == 3


def test_get_all_players(client):
    """L'endpoint /api/players doit retourner les 3 joueurs."""
    response = client.get('/api/players')
    assert response.status_code == 200
    data = response.get_json()
    assert len(data) == 3
    assert 'ShadowFPS' in data
    assert 'ValoAce' in data
    assert 'WarzonePro' in data


def test_get_single_player(client):
    """Un joueur existant doit retourner ses stats avec kd_ratio."""
    response = client.get('/api/players/ShadowFPS')
    assert response.status_code == 200
    data = response.get_json()
    assert 'kd_ratio' in data
    assert 'win_rate' in data
    assert data['game'] == 'CS2'
    assert data['kd_ratio'] > 0


def test_get_unknown_player_returns_404(client):
    """Un joueur inconnu doit retourner 404."""
    response = client.get('/api/players/JoueurInconnu')
    assert response.status_code == 404
    data = response.get_json()
    assert 'error' in data


def test_leaderboard(client):
    """Le leaderboard doit retourner les joueurs triés par K/D."""
    response = client.get('/api/leaderboard')
    assert response.status_code == 200
    data = response.get_json()
    assert 'leaderboard' in data
    assert data['total'] == 3
    kds = [p['kd_ratio'] for p in data['leaderboard']]
    assert kds == sorted(kds, reverse=True)


def test_add_session(client):
    """Enregistrer une session doit mettre à jour les stats."""
    payload = {'kills': 20, 'deaths': 10, 'win': True, 'hours': 1.5}
    response = client.post(
        '/api/players/ValoAce/session',
        data=json.dumps(payload),
        content_type='application/json'
    )
    assert response.status_code == 200
    data = response.get_json()
    assert data['player'] == 'ValoAce'
    assert 'new_kd' in data
    assert 'new_wins' in data


def test_add_session_unknown_player(client):
    """Une session pour un joueur inconnu doit retourner 404."""
    payload = {'kills': 5, 'deaths': 3, 'win': False, 'hours': 0.5}
    response = client.post(
        '/api/players/Inconnu/session',
        data=json.dumps(payload),
        content_type='application/json'
    )
    assert response.status_code == 404


def test_metrics_endpoint(client):
    """L'endpoint /metrics doit exposer les métriques Prometheus."""
    response = client.get('/metrics')
    assert response.status_code == 200
    assert b'fps_tracker_requests_total' in response.data
    assert b'fps_tracker_player_kd_ratio' in response.data
    assert b'fps_tracker_active_sessions' in response.data
