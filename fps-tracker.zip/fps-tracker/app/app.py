from flask import Flask, jsonify, request, render_template_string
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST
import time
import json
import os

app = Flask(__name__)

# ── Stockage en mémoire des joueurs (remplace une vraie DB pour l'éval) ──
PLAYERS = {
    "ShadowFPS": {
        "game": "CS2",
        "kills": 4821,
        "deaths": 2103,
        "wins": 312,
        "losses": 198,
        "hours_played": 1247,
        "headshot_pct": 58.3,
        "rank": "Global Elite"
    },
    "ValoAce": {
        "game": "Valorant",
        "kills": 3204,
        "deaths": 1876,
        "wins": 245,
        "losses": 180,
        "hours_played": 830,
        "headshot_pct": 44.1,
        "rank": "Immortal 2"
    },
    "WarzonePro": {
        "game": "Call of Duty",
        "kills": 9870,
        "deaths": 6200,
        "wins": 87,
        "losses": 413,
        "hours_played": 2100,
        "headshot_pct": 31.7,
        "rank": "Top 250"
    },
}

# ── Métriques Prometheus ───────────────────────────────────────────────────
REQUEST_COUNT = Counter(
    'fps_tracker_requests_total',
    'Nombre total de requêtes reçues',
    ['method', 'endpoint', 'status']
)

ACTIVE_SESSIONS = Gauge(
    'fps_tracker_active_sessions',
    'Sessions joueurs actives en ce moment'
)

REQUEST_LATENCY = Histogram(
    'fps_tracker_request_duration_seconds',
    'Durée des requêtes en secondes',
    ['endpoint'],
    buckets=[0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0]
)

PLAYER_KD = Gauge(
    'fps_tracker_player_kd_ratio',
    'Ratio K/D par joueur et par jeu',
    ['player', 'game']
)

PLAYER_WINS = Gauge(
    'fps_tracker_player_wins_total',
    'Nombre de victoires par joueur',
    ['player', 'game']
)

PLAYER_HOURS = Gauge(
    'fps_tracker_player_hours_played',
    'Heures jouées par joueur',
    ['player', 'game']
)

STAT_UPDATES = Counter(
    'fps_tracker_stat_updates_total',
    'Nombre de mises à jour de stats',
    ['player']
)

# Initialiser les métriques Prometheus avec les données existantes
def init_metrics():
    for name, data in PLAYERS.items():
        kd = round(data['kills'] / max(data['deaths'], 1), 2)
        PLAYER_KD.labels(player=name, game=data['game']).set(kd)
        PLAYER_WINS.labels(player=name, game=data['game']).set(data['wins'])
        PLAYER_HOURS.labels(player=name, game=data['game']).set(data['hours_played'])

init_metrics()

# ── Middleware ─────────────────────────────────────────────────────────────
@app.before_request
def before_request():
    request._start_time = time.time()
    ACTIVE_SESSIONS.inc()

@app.after_request
def after_request(response):
    duration = time.time() - request._start_time
    REQUEST_LATENCY.labels(endpoint=request.path).observe(duration)
    REQUEST_COUNT.labels(
        method=request.method,
        endpoint=request.path,
        status=response.status_code
    ).inc()
    ACTIVE_SESSIONS.dec()
    return response

# ── HTML template minimaliste ──────────────────────────────────────────────
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FPS Tracker</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0c0c0e;
    --surface: #131316;
    --border: #222228;
    --text: #f0f0f2;
    --muted: #6b6b7a;
    --accent: #e8ff57;
    --accent2: #57d4ff;
    --danger: #ff5757;
    --green: #57ffa0;
  }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Syne', sans-serif;
    min-height: 100vh;
    padding: 40px 24px;
  }

  header {
    max-width: 960px;
    margin: 0 auto 48px;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    border-bottom: 1px solid var(--border);
    padding-bottom: 20px;
  }

  .logo {
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.5px;
  }

  .logo span { color: var(--accent); }

  .status-pill {
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    color: var(--green);
    background: rgba(87,255,160,0.08);
    border: 1px solid rgba(87,255,160,0.2);
    padding: 4px 10px;
    border-radius: 99px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .dot {
    width: 6px; height: 6px;
    background: var(--green);
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%,100% { opacity: 1; }
    50% { opacity: 0.3; }
  }

  main { max-width: 960px; margin: 0 auto; }

  .section-label {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    letter-spacing: 2px;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 16px;
  }

  .cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 16px;
    margin-bottom: 48px;
  }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 24px;
    transition: border-color 0.2s;
    animation: fadeUp 0.4s ease both;
  }

  .card:hover { border-color: #333340; }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .card:nth-child(1) { animation-delay: 0.05s; }
  .card:nth-child(2) { animation-delay: 0.10s; }
  .card:nth-child(3) { animation-delay: 0.15s; }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
  }

  .player-name {
    font-size: 18px;
    font-weight: 700;
  }

  .game-tag {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 4px;
    font-weight: 500;
  }

  .tag-cs2   { background: rgba(232,255,87,0.1); color: var(--accent); border: 1px solid rgba(232,255,87,0.2); }
  .tag-valo  { background: rgba(255,87,87,0.1);  color: var(--danger); border: 1px solid rgba(255,87,87,0.2); }
  .tag-cod   { background: rgba(87,212,255,0.1); color: var(--accent2); border: 1px solid rgba(87,212,255,0.2); }

  .stats-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  .stat-block { }

  .stat-label {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-bottom: 2px;
  }

  .stat-value {
    font-size: 22px;
    font-weight: 700;
    line-height: 1;
  }

  .kd-good  { color: var(--green); }
  .kd-ok    { color: var(--accent); }
  .kd-bad   { color: var(--danger); }

  .stat-sub {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    color: var(--muted);
    margin-top: 2px;
  }

  .rank-row {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .rank-label { font-family: 'DM Mono', monospace; font-size: 10px; color: var(--muted); }
  .rank-value { font-size: 13px; font-weight: 700; color: var(--accent); }

  /* Form section */
  .form-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 28px;
    margin-bottom: 48px;
  }

  .form-title {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 20px;
  }

  .form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
  }

  .form-group { display: flex; flex-direction: column; gap: 6px; }

  label {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 1px;
    text-transform: uppercase;
  }

  input, select {
    background: var(--bg);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 9px 12px;
    border-radius: 6px;
    font-family: 'DM Mono', monospace;
    font-size: 13px;
    outline: none;
    transition: border-color 0.15s;
    -webkit-appearance: none;
  }

  input:focus, select:focus { border-color: var(--accent); }

  select option { background: #1a1a1e; }

  button {
    background: var(--accent);
    color: #0c0c0e;
    border: none;
    padding: 10px 22px;
    border-radius: 6px;
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 0.15s;
  }

  button:hover { opacity: 0.85; }

  .toast {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: var(--green);
    color: #0c0c0e;
    padding: 10px 18px;
    border-radius: 8px;
    font-family: 'DM Mono', monospace;
    font-size: 13px;
    font-weight: 500;
    opacity: 0;
    transform: translateY(8px);
    transition: all 0.25s;
    pointer-events: none;
  }

  .toast.show { opacity: 1; transform: translateY(0); }

  /* API links footer */
  .api-links {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 8px;
  }

  .api-link {
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    color: var(--muted);
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 5px 10px;
    border-radius: 5px;
    text-decoration: none;
    transition: color 0.15s, border-color 0.15s;
  }

  .api-link:hover { color: var(--accent); border-color: var(--accent); }
</style>
</head>
<body>

<header>
  <div class="logo">FPS<span>Tracker</span></div>
  <div class="status-pill"><div class="dot"></div>LIVE · Prometheus actif</div>
</header>

<main>
  <p class="section-label">Classement joueurs</p>

  <div class="cards" id="cards-container">
    {% for name, p in players.items() %}
    {% set kd = (p.kills / [p.deaths, 1]|max) | round(2) %}
    {% set wr = ((p.wins / ([p.wins + p.losses, 1]|max)) * 100) | round(1) %}
    {% set game_slug = p.game | lower | replace(' ', '') | replace('of', '') %}
    <div class="card">
      <div class="card-header">
        <span class="player-name">{{ name }}</span>
        <span class="game-tag
          {% if 'cs' in game_slug %}tag-cs2
          {% elif 'val' in game_slug %}tag-valo
          {% else %}tag-cod{% endif %}">
          {{ p.game }}
        </span>
      </div>
      <div class="stats-grid">
        <div class="stat-block">
          <div class="stat-label">K/D Ratio</div>
          <div class="stat-value {% if kd >= 2 %}kd-good{% elif kd >= 1 %}kd-ok{% else %}kd-bad{% endif %}">
            {{ kd }}
          </div>
          <div class="stat-sub">{{ p.kills }}K · {{ p.deaths }}D</div>
        </div>
        <div class="stat-block">
          <div class="stat-label">Win Rate</div>
          <div class="stat-value {% if wr >= 55 %}kd-good{% elif wr >= 45 %}kd-ok{% else %}kd-bad{% endif %}">
            {{ wr }}%
          </div>
          <div class="stat-sub">{{ p.wins }}W · {{ p.losses }}L</div>
        </div>
        <div class="stat-block">
          <div class="stat-label">Heures</div>
          <div class="stat-value" style="color:var(--accent2)">{{ p.hours_played }}</div>
          <div class="stat-sub">heures jouées</div>
        </div>
        <div class="stat-block">
          <div class="stat-label">Headshot %</div>
          <div class="stat-value">{{ p.headshot_pct }}</div>
          <div class="stat-sub">% des kills</div>
        </div>
      </div>
      <div class="rank-row">
        <span class="rank-label">RANG ACTUEL</span>
        <span class="rank-value">{{ p.rank }}</span>
      </div>
    </div>
    {% endfor %}
  </div>

  <!-- Formulaire ajout de kills -->
  <p class="section-label">Enregistrer une session</p>
  <div class="form-card">
    <div class="form-title">Nouvelle session de jeu</div>
    <form onsubmit="submitSession(event)">
      <div class="form-row">
        <div class="form-group">
          <label>Joueur</label>
          <select id="f-player" required>
            {% for name in players.keys() %}
            <option value="{{ name }}">{{ name }}</option>
            {% endfor %}
          </select>
        </div>
        <div class="form-group">
          <label>Kills</label>
          <input type="number" id="f-kills" min="0" max="200" value="18" required>
        </div>
        <div class="form-group">
          <label>Deaths</label>
          <input type="number" id="f-deaths" min="0" max="200" value="9" required>
        </div>
        <div class="form-group">
          <label>Victoire ?</label>
          <select id="f-win">
            <option value="1">Oui</option>
            <option value="0">Non</option>
          </select>
        </div>
        <div class="form-group">
          <label>Heures</label>
          <input type="number" id="f-hours" min="0" max="24" step="0.5" value="1.5" required>
        </div>
      </div>
      <button type="submit">Enregistrer la session</button>
    </form>
  </div>

  <p class="section-label">Endpoints de l'API</p>
  <div class="api-links">
    <a class="api-link" href="/api/players">/api/players</a>
    <a class="api-link" href="/api/players/ShadowFPS">/api/players/:name</a>
    <a class="api-link" href="/api/leaderboard">/api/leaderboard</a>
    <a class="api-link" href="/health">/health</a>
    <a class="api-link" href="/metrics">/metrics</a>
  </div>
</main>

<div class="toast" id="toast">Session enregistrée ✓</div>

<script>
async function submitSession(e) {
  e.preventDefault();
  const payload = {
    kills:  parseInt(document.getElementById('f-kills').value),
    deaths: parseInt(document.getElementById('f-deaths').value),
    win:    document.getElementById('f-win').value === '1',
    hours:  parseFloat(document.getElementById('f-hours').value)
  };
  const player = document.getElementById('f-player').value;
  const res = await fetch('/api/players/' + player + '/session', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
  if (res.ok) {
    showToast();
    setTimeout(() => location.reload(), 900);
  }
}

function showToast() {
  const t = document.getElementById('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}
</script>
</body>
</html>"""

# ── Routes ─────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, players=PLAYERS)

@app.route('/health')
def health():
    return jsonify({
        "status": "ok",
        "service": "fps-tracker",
        "version": "1.0.0",
        "players_tracked": len(PLAYERS)
    }), 200

@app.route('/api/players')
def get_players():
    result = {}
    for name, data in PLAYERS.items():
        kd = round(data['kills'] / max(data['deaths'], 1), 2)
        wr = round(data['wins'] / max(data['wins'] + data['losses'], 1) * 100, 1)
        result[name] = {**data, "kd_ratio": kd, "win_rate": wr}
    return jsonify(result)

@app.route('/api/players/<player_name>')
def get_player(player_name):
    if player_name not in PLAYERS:
        return jsonify({"error": "Joueur introuvable"}), 404
    data = PLAYERS[player_name]
    kd = round(data['kills'] / max(data['deaths'], 1), 2)
    wr = round(data['wins'] / max(data['wins'] + data['losses'], 1) * 100, 1)
    return jsonify({**data, "kd_ratio": kd, "win_rate": wr})

@app.route('/api/players/<player_name>/session', methods=['POST'])
def add_session(player_name):
    if player_name not in PLAYERS:
        return jsonify({"error": "Joueur introuvable"}), 404
    body = request.get_json()
    if not body:
        return jsonify({"error": "Corps JSON manquant"}), 400

    kills  = int(body.get('kills', 0))
    deaths = int(body.get('deaths', 0))
    win    = bool(body.get('win', False))
    hours  = float(body.get('hours', 0))

    p = PLAYERS[player_name]
    p['kills']        += kills
    p['deaths']       += deaths
    p['hours_played'] += hours
    if win:
        p['wins'] += 1
    else:
        p['losses'] += 1

    # Mettre à jour les métriques Prometheus
    kd = round(p['kills'] / max(p['deaths'], 1), 2)
    PLAYER_KD.labels(player=player_name, game=p['game']).set(kd)
    PLAYER_WINS.labels(player=player_name, game=p['game']).set(p['wins'])
    PLAYER_HOURS.labels(player=player_name, game=p['game']).set(p['hours_played'])
    STAT_UPDATES.labels(player=player_name).inc()

    return jsonify({
        "message": "Session enregistrée",
        "player": player_name,
        "new_kd": kd,
        "new_wins": p['wins']
    }), 200

@app.route('/api/leaderboard')
def leaderboard():
    board = []
    for name, data in PLAYERS.items():
        kd = round(data['kills'] / max(data['deaths'], 1), 2)
        wr = round(data['wins'] / max(data['wins'] + data['losses'], 1) * 100, 1)
        board.append({
            "player": name,
            "game": data['game'],
            "kd_ratio": kd,
            "win_rate": wr,
            "hours": data['hours_played'],
            "rank": data['rank']
        })
    board.sort(key=lambda x: x['kd_ratio'], reverse=True)
    return jsonify({"leaderboard": board, "total": len(board)})

@app.route('/metrics')
def metrics():
    return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
