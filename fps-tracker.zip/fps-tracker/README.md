# FPS Tracker — DevOps Final

![CI/CD](https://github.com/TON-USERNAME/fps-tracker/actions/workflows/ci.yml/badge.svg)

Tracker de statistiques FPS (CS2, Valorant, Call of Duty) avec monitoring Prometheus + Grafana et pipeline CI/CD GitHub Actions.

Projet d'évaluation finale — Module DevOps · Groupe de 3

---

## Stack technique

| Composant | Technologie |
|-----------|-------------|
| Application | Python · Flask |
| Métriques | Prometheus Client |
| Monitoring | Prometheus · Grafana |
| Conteneurisation | Docker · Docker Compose |
| CI/CD | GitHub Actions |
| Registry | Docker Hub |

## Lancement rapide

```bash
git clone https://github.com/TON-USERNAME/fps-tracker.git
cd fps-tracker
docker compose up --build -d
```

## URLs

| Service    | URL                      | Auth               |
|------------|--------------------------|--------------------|
| FPS Tracker | http://localhost:5000   | —                  |
| Prometheus | http://localhost:9090    | —                  |
| Grafana    | http://localhost:3000    | admin / devops2024 |

## Endpoints API

| Route | Méthode | Description |
|-------|---------|-------------|
| `/` | GET | Dashboard UI |
| `/health` | GET | Healthcheck |
| `/api/players` | GET | Tous les joueurs |
| `/api/players/:name` | GET | Stats d'un joueur |
| `/api/players/:name/session` | POST | Enregistrer une session |
| `/api/leaderboard` | GET | Classement par K/D |
| `/metrics` | GET | Métriques Prometheus |

## Métriques Prometheus

| Métrique | Type | Description |
|----------|------|-------------|
| `fps_tracker_requests_total` | Counter | Requêtes par endpoint/status |
| `fps_tracker_active_sessions` | Gauge | Sessions en cours |
| `fps_tracker_request_duration_seconds` | Histogram | Latence des requêtes |
| `fps_tracker_player_kd_ratio` | Gauge | K/D par joueur |
| `fps_tracker_player_wins_total` | Gauge | Victoires par joueur |
| `fps_tracker_player_hours_played` | Gauge | Heures jouées |
| `fps_tracker_stat_updates_total` | Counter | Sessions enregistrées |

## Requêtes PromQL pour Grafana

```promql
# Taux de requêtes / seconde
rate(fps_tracker_requests_total[1m])

# K/D de tous les joueurs
fps_tracker_player_kd_ratio

# Latence moyenne en ms
rate(fps_tracker_request_duration_seconds_sum[5m])
/ rate(fps_tracker_request_duration_seconds_count[5m]) * 1000

# Nombre de sessions enregistrées
fps_tracker_stat_updates_total
```

## Pipeline CI/CD

```
push → lint (flake8) → test (pytest · 9 tests) → build Docker → push Docker Hub
```

Le push vers Docker Hub n'a lieu que sur la branche `main`.

## Secrets GitHub à configurer

Settings → Secrets and variables → Actions :

| Secret | Valeur |
|--------|--------|
| `DOCKERHUB_USERNAME` | Ton username Docker Hub |
| `DOCKERHUB_TOKEN` | Token généré sur hub.docker.com |

## Commandes utiles

```bash
# Logs en temps réel
docker compose logs fps-tracker -f

# Tests en local
pip install -r app/requirements.txt
pytest app/tests/ -v

# Générer du trafic pour Prometheus
for i in $(seq 1 50); do curl -s http://localhost:5000/api/leaderboard > /dev/null; done

# Arrêt complet
docker compose down -v
```

## Enregistrer une session via curl

```bash
curl -X POST http://localhost:5000/api/players/ShadowFPS/session \
  -H "Content-Type: application/json" \
  -d '{"kills": 25, "deaths": 8, "win": true, "hours": 1.5}'
```
